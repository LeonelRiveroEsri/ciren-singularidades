// utm.js
// Conversión de Latitud/Longitud (WGS84) a coordenadas UTM Este y Norte
 
var utmE = function (latDeg, lonDeg) {
  return latLonToUTM(latDeg, lonDeg).easting;
};
 
var utmN = function (latDeg, lonDeg) {
  return latLonToUTM(latDeg, lonDeg).northing;
};
 
var utmZone = function (latDeg, lonDeg) {
  var r = latLonToUTM(latDeg, lonDeg);
  return r.zone + r.hemisphere;
};
 
// ---- Función principal ----
function latLonToUTM(latDeg, lonDeg) {
  const a = 6378137.0;
  const f = 1 / 298.257223563;
  const b = a * (1 - f);
  const e2 = 1 - (b * b) / (a * a);
  const e4 = e2 * e2;
  const e6 = e4 * e2;
  const ep2 = e2 / (1 - e2);
  const k0 = 0.9996;
 
  function degToRad(d) { return d * Math.PI / 180.0; }
 
  function zoneFromLon(lon) {
    let z = Math.floor((lon + 180.0) / 6.0) + 1;
    return Math.min(Math.max(z, 1), 60);
  }
 
  function centralMeridian(zone) {
    return degToRad(-183.0 + 6.0 * zone);
  }
 
  function meridionalArc(phi) {
    return a * (
      (1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi
      - (3 * e2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * Math.sin(2 * phi)
      + (15 * e4 / 256 + 45 * e6 / 1024) * Math.sin(4 * phi)
      - (35 * e6 / 3072) * Math.sin(6 * phi)
    );
  }
 
  const zone = zoneFromLon(lonDeg);
  const lambda0 = centralMeridian(zone);
  const phi = degToRad(latDeg);
  const lambda = degToRad(lonDeg);
 
  const sinPhi = Math.sin(phi);
  const cosPhi = Math.cos(phi);
  const tanPhi = Math.tan(phi);
 
  const N = a / Math.sqrt(1 - e2 * sinPhi * sinPhi);
  const T = tanPhi * tanPhi;
  const C = ep2 * cosPhi * cosPhi;
  const A = cosPhi * (lambda - lambda0);
  const M = meridionalArc(phi);
 
  const E = k0 * N * (
    A + (1 - T + C) * Math.pow(A, 3) / 6 +
    (5 - 18 * T + T * T + 72 * C - 58 * ep2) * Math.pow(A, 5) / 120
  ) + 500000.0;
 
  let Nn = k0 * (
    M + N * tanPhi * (
      Math.pow(A, 2) / 2 +
      (5 - T + 9 * C + 4 * C * C) * Math.pow(A, 4) / 24 +
      (61 - 58 * T + T * T + 600 * C - 330 * ep2) * Math.pow(A, 6) / 720
    )
  );
 
  const hemisphere = (latDeg >= 0) ? "N" : "S";
  if (hemisphere === "S") Nn += 10000000.0;
 
  return { easting: E, northing: Nn, zone: zone, hemisphere: hemisphere };
}