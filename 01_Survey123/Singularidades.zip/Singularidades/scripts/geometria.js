/**
 * Obtiene el punto situado a la mitad de la longitud de un geotrace.
 *
 * Entrada:
 * {
 *   "spatialReference": {"wkid": 4326},
 *   "paths": [[[x, y, z], [x, y, z], ...]]
 * }
 *
 * Salida para una pregunta geopoint:
 * "latitud longitud altitud precisión"
 */
function puntoMedioLinea(geometria) {
  try {
    if (geometria === null || geometria === undefined) {
      return "";
    }

    // Survey123 puede entregar el objeto directamente
    // o como una cadena JSON.
    if (typeof geometria === "string") {
      geometria = geometria.trim();

      if (geometria === "") {
        return "";
      }

      geometria = JSON.parse(geometria);
    }

    if (
      !geometria.paths ||
      !Array.isArray(geometria.paths) ||
      geometria.paths.length === 0 ||
      !Array.isArray(geometria.paths[0])
    ) {
      return "";
    }

    var vertices = geometria.paths[0];

    if (vertices.length === 0) {
      return "";
    }

    if (vertices.length === 1) {
      return formatearGeopoint(vertices[0]);
    }

    var longitudes = [];
    var longitudTotal = 0;

    for (var i = 0; i < vertices.length - 1; i++) {
      var puntoInicial = vertices[i];
      var puntoFinal = vertices[i + 1];

      var distancia = distanciaHaversine(
        puntoInicial[1], // latitud
        puntoInicial[0], // longitud
        puntoFinal[1],
        puntoFinal[0],
      );

      longitudes.push(distancia);
      longitudTotal += distancia;
    }

    if (longitudTotal === 0) {
      return formatearGeopoint(vertices[0]);
    }

    var distanciaObjetivo = longitudTotal / 2;
    var distanciaAcumulada = 0;

    for (var j = 0; j < longitudes.length; j++) {
      var longitudTramo = longitudes[j];

      if (distanciaAcumulada + longitudTramo >= distanciaObjetivo) {
        var proporcion =
          (distanciaObjetivo - distanciaAcumulada) / longitudTramo;

        var inicio = vertices[j];
        var fin = vertices[j + 1];

        var longitud = inicio[0] + proporcion * (fin[0] - inicio[0]);

        var latitud = inicio[1] + proporcion * (fin[1] - inicio[1]);

        var elevacionInicial =
          inicio.length > 2 && inicio[2] !== null ? Number(inicio[2]) : 0;

        var elevacionFinal =
          fin.length > 2 && fin[2] !== null ? Number(fin[2]) : elevacionInicial;

        var elevacion =
          elevacionInicial + proporcion * (elevacionFinal - elevacionInicial);

        // Formato geopoint:
        // latitud longitud altitud precisión
        return latitud + " " + longitud + " " + elevacion + " 0";
      }

      distanciaAcumulada += longitudTramo;
    }

    return formatearGeopoint(vertices[vertices.length - 1]);
  } catch (error) {
    console.error("Error calculando el punto medio:", error);
    return "";
  }
}

function formatearGeopoint(vertice) {
  var longitud = Number(vertice[0]);
  var latitud = Number(vertice[1]);

  var elevacion =
    vertice.length > 2 && vertice[2] !== null ? Number(vertice[2]) : 0;

  return latitud + " " + longitud + " " + elevacion + " 0";
}

function distanciaHaversine(lat1, lon1, lat2, lon2) {
  var radioTierra = 6371000;

  var lat1Rad = (lat1 * Math.PI) / 180;
  var lat2Rad = (lat2 * Math.PI) / 180;

  var deltaLat = ((lat2 - lat1) * Math.PI) / 180;
  var deltaLon = ((lon2 - lon1) * Math.PI) / 180;

  var a =
    Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
    Math.cos(lat1Rad) *
      Math.cos(lat2Rad) *
      Math.sin(deltaLon / 2) *
      Math.sin(deltaLon / 2);

  return 2 * radioTierra * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
